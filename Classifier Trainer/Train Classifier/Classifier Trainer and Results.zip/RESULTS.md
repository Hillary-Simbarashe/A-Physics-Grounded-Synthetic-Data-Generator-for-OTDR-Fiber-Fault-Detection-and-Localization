# Classifier Results: Random Forest on Generated OTDR Traces

**Model:** Random Forest (300 trees, balanced class weights), scikit-learn 1.8.0
**Features:** 30-point max-pooled, min-max normalized trace summary (computed independently of the uploaded file's own `downsample_normalize()`, which still uses nearest-index sampling — see note below)
**Generator used:** `otdr_dataset_generator_fixed.py` (as uploaded), which includes the relative-spike-height and fiber-cut-margin fixes, but **not** the disjoint-loss-range fix or the max-pool downsampling fix from earlier rounds
**Train/test:** 8,000 / 2,000 single-event traces, SNR ∈ [-5, 20] dB, independent random seeds

## 1. Overall Results (Single-Event Test Set)

| Metric | Value |
|---|---|
| Accuracy | **0.516** |
| Macro F1 | **0.521** |
| Weighted F1 | **0.511** |

### Per-class breakdown

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| normal | 0.357 | 0.385 | 0.370 | 239 |
| fiber_tapping | 0.321 | 0.516 | 0.396 | 254 |
| bad_splice | 0.338 | 0.264 | 0.296 | 284 |
| bending | 0.480 | 0.423 | 0.450 | 286 |
| dirty_connector | 0.265 | 0.201 | 0.229 | 239 |
| **fiber_cut** | **0.979** | **0.996** | **0.987** | 233 |
| **pc_connector** | **0.828** | **0.902** | **0.864** | 235 |
| reflector | 0.645 | 0.522 | 0.577 | 230 |

**Confusion matrix:** see `fig_confusion_matrix.png`.

### Interpretation

The 8-class average (51.6% accuracy) hides a sharp two-tier split:

- **fiber_cut, pc_connector, reflector** (the three classes with a distinctive reflective spike) classify very well (F1 0.58–0.99).
- **normal, fiber_tapping, bad_splice, dirty_connector, bending** (the five non-reflective / no-event classes, distinguished only by loss magnitude) are heavily confused with each other, with F1 as low as 0.23.

This is not a modeling failure — it is a direct, measurable consequence of the loss ranges in this uploaded generator file still overlapping for `bad_splice` (0.3–3.0 dB), `dirty_connector` (0.5–4.0 dB), and `bending` (0.5–6.0 dB), and of `fiber_tapping`'s loss range (0.05–0.5 dB) being nearly indistinguishable from noise/`normal`. This is exactly the class-separability issue flagged earlier in this project; this run quantifies its real impact on a trained classifier rather than just the label ranges on paper.

## 2. Performance vs. SNR (Single-Event Traces)

| SNR bin | Accuracy | Macro F1 |
|---|---|---|
| -5 to 0 dB | 0.387 | 0.385 |
| 0 to 5 dB | 0.453 | 0.455 |
| 5 to 10 dB | 0.553 | 0.546 |
| 10 to 15 dB | 0.563 | 0.566 |
| 15 to 20 dB | 0.588 | 0.565 |

See `fig_snr_sweep_performance.png`. Performance rises monotonically with SNR as expected, but **plateaus around 0.55–0.59** even at the best SNR tested — confirming the ceiling is set by class overlap, not by noise. A perfectly denoised trace would not fix this; only disjoint loss ranges (or an additional discriminating feature, e.g. the dual-wavelength signal discussed earlier) would.

## 3. Compound (Multi-Fault) Trace Evaluation

500 compound traces (2–4 overlapping/co-occurring events each, `fiber_cut` excluded from the pool as in the generator's own design) were passed through the same single-label classifier trained only on single-event traces.

| Metric | Value |
|---|---|
| "Any-match" rate (prediction is *one of* the true present classes) | 0.724 |
| "Anchor-match" rate (prediction equals the first-placed/anchor event specifically) | 0.392 |

### Per-class recovery rate when present in a compound trace

| Class | Recovered / Present | Rate |
|---|---|---|
| pc_connector | 164 / 191 | **0.859** |
| reflector | 88 / 178 | 0.494 |
| bending | 66 / 172 | 0.384 |
| fiber_tapping | 19 / 185 | 0.103 |
| dirty_connector | 15 / 179 | 0.084 |
| bad_splice | 10 / 173 | 0.058 |

See `fig_compound_evaluation.png`.

### Interpretation

A single-label classifier trained on single-event traces, when handed a compound trace, essentially picks whichever event has the strongest, most distinctive signature — overwhelmingly `pc_connector` (predicted for 177/500 compound traces) and `reflector` (114/500) — and almost never reports the weaker non-reflective classes even when they are genuinely present. This is exactly what one would expect: it demonstrates empirically that **a single-label architecture is structurally unsuited to compound-fault traces**, not merely under-tested on them. It reinforces the case, made in the earlier literature review and paper, for a multi-label or sequence-labeling formulation (and for calibrated uncertainty, since here the model gives no signal at all that a second, undetected fault may be present).

## Files

- `rf_classifier.joblib` — trained model
- `fig_confusion_matrix.png`, `fig_snr_sweep_performance.png`, `fig_compound_evaluation.png` — figures above
- `classification_report.txt`, `snr_sweep_results.csv`, `compound_summary.csv`, `test_predictions.csv` — raw numbers
