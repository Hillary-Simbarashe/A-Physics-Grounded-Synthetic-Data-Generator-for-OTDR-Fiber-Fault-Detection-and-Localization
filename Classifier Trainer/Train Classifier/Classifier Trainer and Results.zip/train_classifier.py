import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, f1_score, confusion_matrix, classification_report,
)
import joblib

from data_pipeline import build_single_event_dataset, CLASSES

SEED = 42
SNR_RANGE = (-5, 20)

print("Generating training set...")
X_train, meta_train = build_single_event_dataset(8000, SNR_RANGE, seed=SEED)
print("Generating held-out test set (different seed)...")
X_test, meta_test = build_single_event_dataset(2000, SNR_RANGE, seed=SEED + 1)

y_train = meta_train["class"].values
y_test = meta_test["class"].values

print("Train class balance:\n", meta_train["class_name"].value_counts())
print("\nTest class balance:\n", meta_test["class_name"].value_counts())

clf = RandomForestClassifier(
    n_estimators=300, max_depth=None, random_state=SEED, n_jobs=-1,
    class_weight="balanced",
)
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)

acc = accuracy_score(y_test, y_pred)
f1_macro = f1_score(y_test, y_pred, average="macro")
f1_weighted = f1_score(y_test, y_pred, average="weighted")

print(f"\nOverall test accuracy: {acc:.4f}")
print(f"Macro F1: {f1_macro:.4f}")
print(f"Weighted F1: {f1_weighted:.4f}")

class_names = [CLASSES[i] for i in range(8)]
report = classification_report(y_test, y_pred, target_names=class_names, digits=3)
print("\nPer-class classification report:\n", report)

cm = confusion_matrix(y_test, y_pred, labels=list(range(8)))
print("\nConfusion matrix (rows=true, cols=pred):\n", cm)

# Save everything needed downstream
joblib.dump(clf, "rf_classifier.joblib")
np.save("cm_single_event.npy", cm)
meta_test["pred_class"] = y_pred
meta_test.to_csv("test_predictions.csv", index=False)
with open("classification_report.txt", "w") as f:
    f.write(f"Overall accuracy: {acc:.4f}\nMacro F1: {f1_macro:.4f}\nWeighted F1: {f1_weighted:.4f}\n\n")
    f.write(report)

print("\nSaved: rf_classifier.joblib, cm_single_event.npy, test_predictions.csv, classification_report.txt")
